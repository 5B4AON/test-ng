import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent {

  showIcons: boolean = false;
  value1: number = 0;
  value2: number = 0;
  value3: number = 0.34;

   
}